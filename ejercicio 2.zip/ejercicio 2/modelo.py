
def isDigitIncreasing(numero: int) -> int:
    for n in range(1, 10):
        suma = 0
        termino = 0
        while suma < numero:
            termino = termino * 10 + n   
            suma += termino
            if suma == numero:
                return 1  
    return 0  
