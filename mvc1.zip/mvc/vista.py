
class VistaAgenda:
    def mostrar_contactos(self, contactos):
        print("\n--- Contactos ---")
        for c in contactos:
            print(f"Nombre: {c.nombre} | Teléfono: {c.telefono}")

    def mostrar_mensaje(self, mensaje):
        print(mensaje)
