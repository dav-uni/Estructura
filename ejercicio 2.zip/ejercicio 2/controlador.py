
import modelo
import vista

def ejecutar():
    numero = vista.pedir_numero()
    resultado = modelo.isDigitIncreasing(numero)
    vista.mostrar_resultado(numero, resultado)
