
class ControladorAgenda:
    def __init__(self, modelo, vista):
        self.modelo = modelo
        self.vista = vista

    def agregar_contacto(self, nombre, telefono):
        self.modelo.agregar_contacto(nombre, telefono)
        self.vista.mostrar_mensaje("✅ Contacto agregado!")

    def ver_contactos(self):
        contactos = self.modelo.obtener_contactos()
        self.vista.mostrar_contactos(contactos)
