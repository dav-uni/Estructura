
def padovan(n: int) -> int:
    # Casos base
    if n == 0 or n == 1 or n == 2:
        return 1
    # Caso recursivo
    return padovan(n - 2) + padovan(n - 3)
