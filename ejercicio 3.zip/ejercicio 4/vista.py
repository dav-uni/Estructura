
def pedir_numero():
    return int(input("Ingrese el valor de n para la serie de Padovan: "))

def mostrar_resultado(n, resultado):
    print(f"El término P({n}) de la serie de Padovan es: {resultado}")
