
class Contacto:
    def __init__(self, nombre, telefono):
        self.nombre = nombre
        self.telefono = telefono


class Agenda:
    def __init__(self):
        self.contactos = []

    def agregar_contacto(self, nombre, telefono):
        nuevo = Contacto(nombre, telefono)
        self.contactos.append(nuevo)

    def obtener_contactos(self):
        return self.contactos
