
def pedir_numero():
    return int(input("Ingrese un número: "))

def mostrar_resultado(numero, resultado):
    if resultado == 1:
        print(f"✅ El número {numero} es digit-increasing")
    else:
        print(f"❌ El número {numero} NO es digit-increasing")
