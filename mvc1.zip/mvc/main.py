from modelo import Agenda
from vista import VistaAgenda
from controlador import ControladorAgenda

if __name__ == "__main__":
    modelo = Agenda()           
    vista = VistaAgenda()       
    controlador = ControladorAgenda(modelo, vista)  

    while True:
        print("\n1. Agregar contacto")
        print("2. Ver contactos")
        print("3. Salir")
        opcion = input("Elige una opción: ")

        if opcion == "1":
            nombre = input("Nombre: ")
            telefono = input("Teléfono: ")
            controlador.agregar_contacto(nombre, telefono)

        elif opcion == "2":
            controlador.ver_contactos()

        elif opcion == "3":
            print("Hasta luego 👋")
            break

        else:
            print("❌ Opción no válida")
